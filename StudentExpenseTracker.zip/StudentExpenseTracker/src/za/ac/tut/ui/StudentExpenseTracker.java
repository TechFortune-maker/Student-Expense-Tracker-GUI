
package za.ac.tut.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import za.ac.tut.expense.Expense;

public class StudentExpenseTracker extends JFrame{
    //panels 
    private JPanel headingPnl;
    private JPanel addExpensePnl;
    private JPanel categoryPnl;
    private JPanel amountPnl;
    private JPanel descriptionPnl;
    private JPanel monthlySummaryPnl;
    private JPanel addExepnseAndMonthlySummary;
    private JPanel buttonPnl;
    
    private JPanel mainPnl;
    
    
    //label
    private JLabel headingLbl;
    private JLabel categoryLbl;
    private JLabel amountLbl;
    private JLabel descriptionLbl;
    
    //buttons
    private JButton addExpenseBtn;
    private JButton viewSummaryBtn;
    private JButton clearBtn;
    
    //text area 
    private JTextArea monthlySalary;

    //text fields
    private JTextField descriptionTld; 
    private JTextField amountTld;
    
    //comboBox
    private JComboBox categoryComboBox;
    
    //scrollable Pane
    private JScrollPane scrollPane;

    public StudentExpenseTracker() {
        
        
        setTitle("Student Expense Tracker");
        setSize(700,800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        
        //create panels
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        addExpensePnl = new JPanel(new GridLayout(2, 1, 1, 1));
        addExpensePnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1),"Add Expense"));
        categoryPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        amountPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        descriptionPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        monthlySummaryPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));

        buttonPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        addExepnseAndMonthlySummary = new JPanel(new BorderLayout());
        
        mainPnl = new JPanel(new BorderLayout());
        
        //labels
        headingLbl = new JLabel("Student Expense Tracker");
        headingLbl.setFont(new Font(Font.SANS_SERIF , Font.ITALIC + Font.BOLD,20));
        headingLbl.setForeground(Color.BLUE);
        headingLbl.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
        
        categoryLbl = new JLabel("Category");
        amountLbl = new JLabel("Amount");
        descriptionLbl = new JLabel("Description");
        
        //text fields
        
        descriptionTld = new JTextField(40);
        amountTld = new JTextField(13);
        
        //combo box
        categoryComboBox = new JComboBox();
        categoryComboBox.addItem("Food");
        categoryComboBox.addItem("Transportation");
        categoryComboBox.addItem("Rent");
        
        //buttons
        addExpenseBtn = new JButton("Add Expense");
        addExpenseBtn.addActionListener(new AddExpenseListener());
        
        viewSummaryBtn = new JButton("View Summary");
        viewSummaryBtn.addActionListener(new viewSummaryBtnListener());
        
        clearBtn = new JButton("Clear Button");
        clearBtn.addActionListener(new clearBtnListener());
        
        
        
        //create text area 
        monthlySalary = new JTextArea(15,50);
        monthlySalary.setEditable(false);
        monthlySalary.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1),"Monthly Summary"));
        
        //create a scrollpane
        scrollPane = new JScrollPane(monthlySalary, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                               JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        
        //add components to the panels      
        headingPnl.add(headingLbl);
        
        categoryPnl.add(categoryLbl);
        categoryPnl.add(categoryComboBox);
        
        
        amountPnl.add(amountLbl);
        amountPnl.add(amountTld);
        
        categoryPnl.add(amountPnl);
        categoryPnl.add(addExpenseBtn);
        
        
        descriptionPnl.add(descriptionLbl);
        descriptionPnl.add(descriptionTld);
        
        //add category panel to their collective panel
        addExpensePnl.add(categoryPnl);
        addExpensePnl.add(descriptionPnl);
        
        monthlySummaryPnl.add(monthlySalary);
        
        //add expense and monthly salary collective panel
        addExepnseAndMonthlySummary.add(headingPnl, BorderLayout.NORTH);
        addExepnseAndMonthlySummary.add(addExpensePnl, BorderLayout.CENTER);
  
        buttonPnl.add(viewSummaryBtn);
        buttonPnl.add(clearBtn);
        
        mainPnl.add(addExepnseAndMonthlySummary, BorderLayout.NORTH);
        mainPnl.add(monthlySalary, BorderLayout.CENTER);
        mainPnl.add(buttonPnl,BorderLayout.SOUTH);
        
        add(mainPnl);
        setLocationRelativeTo(null);
        pack();
        
        
        setVisible(true);
        
    }private class  AddExpenseListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            //read data from the text fields
            String category,description,amount;
            double price=0;
            
            category = (String)categoryComboBox.getSelectedItem();
            description = descriptionTld.getText();
            amount = amountTld.getText();
            
            price = Double.parseDouble(amount);
            
            //call the expense constructor
            Expense expense = new Expense(category, price, description);
            
            try {
                //store data in a text file
                BufferedWriter bw = new BufferedWriter(new FileWriter("expense.txt",true));
                
                bw.write(expense.toString()+"\n");
                bw.close();
                
                JOptionPane.showMessageDialog(StudentExpenseTracker.this, "Log expenses added successfully!!");
                
                
            } catch (IOException ex) {
                Logger.getLogger(StudentExpenseTracker.class.getName()).log(Level.SEVERE, null, ex);
            }
      
        }
     }private class clearBtnListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            amountTld.setText("");
            descriptionTld.setText("");
            monthlySalary.setText("");
             
        }
    
     }
     private class viewSummaryBtnListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            String record="", data="";
            
            try {
                //reading from a file
                BufferedReader br = new BufferedReader(new FileReader("expense.txt"));
                
                while((data = br.readLine()) != null){
                    
                    //record each an every line of text
                    record += data +"\n";
                }
                //close the reading stream
                br.close();
                
                //append the data to the text area 
                monthlySalary.append(record);
                    
                
            } catch (FileNotFoundException ex) {
                Logger.getLogger(StudentExpenseTracker.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(StudentExpenseTracker.class.getName()).log(Level.SEVERE, null, ex);
            }
      
        }
   
     }

}

