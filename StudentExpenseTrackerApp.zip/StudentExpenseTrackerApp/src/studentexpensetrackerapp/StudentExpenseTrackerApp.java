
package studentexpensetrackerapp;

import za.ac.tut.ui.StudentExpenseTracker;


public class StudentExpenseTrackerApp {

  
    public static void main(String[] args) {
       
        
        new StudentExpenseTracker();
        
    }
    
}
